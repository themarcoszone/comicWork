$(function () {
    $('#advertisment').unslider();
});